// // import React from 'react';
// // import {BaseComponentProps} from  "@cloudscape-design/components"; 
// import { SideNavigationProps } from "@cloudscape-design/components"
// import useOnFollow from "../../common/hooks/use-on-follow";
// import { AppContext } from "../../common/app-context";
// import { ContentType } from "../chatbot/types";
// import { FC } from "react";
// hi
//  interface SideBarContentProps {
//     /** Controls the header that appears at the top of the navigation component 
//      * 
//     */
//    contentType: ContentType
//    data: any[]  
//    // activeHref: string 
// }

// export const SidebarContent: FC<SideBarContentProps> = ({
//     contentType,
    
    
// }) => {
//     return (
//         <div className="flex max-h[calc(100%-50px)] grow flex-col">
//         </div>
//     )
// }
// {/* <Link to={`/chatbot/playground/${e.session_id}`}>{e.session_id}</Link> */}


